﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using System.Runtime.InteropServices;

namespace GENX64Test4._6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private Thread test1,test6;
        const short CORE = 1;
        short axis, testtry1,b;
        bool[] en = new bool[32];
        bool test4flag=false, home2flag=false, home3flag = false;
        int pos, encpos1;
        uint clk;
        double vel, prfvel, prfpos, encvel, encpos;
        GTN.mc.TTrapPrm trap;
        GTN.mc.TJogPrm jog;
        short sProbePrm;        // 探针参数
        ushort usProbeSts;      // 探针捕获状态
        int iRiseValue1, iRiseValue2, iFallValue1, iFallValue2; // 探针捕获值
        ushort ECatiooffset, Ecatsize;
        byte Ecatiovalue;
        public Form2 form2;
        [DllImport("user32.dll")]
        public extern static int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
        [DllImport("user32.dll")]
        public extern static IntPtr GetForegroundWindow();
        #region   ///复位加设值编码器值
        private void button1_Click_1(object sender, EventArgs e)
        {
            short rtn;
            rtn = GTN.mc.GTN_Reset(CORE);
            if (rtn != 0)
                MessageBox.Show("GTN_Reset" + rtn.ToString());
            for (short i=1;i<32;i++)
            {
                rtn = GTN.mc.GTN_EncOn(CORE, i);
            //   rtn = GTN.mc.GTN_SetSense(CORE, 23,i, 0);          
            }

        }
        #endregion
        #region   ///点位运动
        private void button3_Click(object sender, EventArgs e)
        {
            short sRtn;
            vel = Convert.ToDouble(this.textBox1.Text);
            pos = (Int32)prfpos + Convert.ToInt32(this.textBox2.Text);
            trap.acc = Convert.ToDouble(this.textBox3.Text);
            trap.dec = Convert.ToDouble(this.textBox4.Text);
           // trap.smoothTime = 10 *（Convert.ToInt16(this.textBox5.Text）);
            trap.smoothTime = 10 ;
            trap.velStart = 0;
            sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
            if (sRtn != 0)
                MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
            sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
            if (sRtn != 0)
                MessageBox.Show("GTN_Update" + sRtn.ToString());
        }
        #endregion
        #region  ///使能
        private void button4_Click(object sender, EventArgs e)
        {
            short sRtn;
            if (!en[axis])
            {
                sRtn = GTN.mc.GTN_AxisOn(CORE, axis); //上伺服 
                if (sRtn != 0)
                    MessageBox.Show("GTN_AxisON" + sRtn.ToString());
            }
            else
            {
                sRtn = GTN.mc.GTN_AxisOff(CORE, axis); //下伺服  
                if (sRtn != 0)
                    MessageBox.Show("GTN_AxisOff" + sRtn.ToString());
            }
            en[axis] = !en[axis];
        }
        #endregion
        private void button6_Click(object sender, EventArgs e)
        {
            short sRtn;
            sRtn= GTN.mc.GTN_ZeroPos(CORE, axis, 1);
            if (sRtn != 0)
                MessageBox.Show("GTN_ZeroPos" + sRtn.ToString());
        }
        #region //JOG运动
        private void JOG正Start(object sender, MouseEventArgs e)
        {
            short sRtn;
            vel = Convert.ToDouble(this.textBox1.Text);
            jog.acc = Convert.ToDouble(this.textBox3.Text);
            jog.dec = Convert.ToDouble(this.textBox4.Text);
            jog.smooth = Convert.ToDouble(this.textBox5.Text);
            sRtn = GTN.mc.GTN_PrfJog(CORE, axis); // 设置为Jog运动模式
            sRtn = GTN.mc.GTN_SetJogPrm(CORE, axis, ref jog); // 设置Jog运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动   
            if (sRtn != 0)
                MessageBox.Show("GTN_Update" + sRtn.ToString());
        }
        private void JOG正stop(object sender, MouseEventArgs e)
        {
            short sRtn;
            sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 0);   // 平滑停止
            if (sRtn != 0)
                MessageBox.Show("GTN_Stop" + sRtn.ToString());

        }
        private void JOG负Start(object sender, MouseEventArgs e)
        {
            short sRtn;
            vel = Convert.ToDouble(this.textBox1.Text);
            jog.acc = Convert.ToDouble(this.textBox3.Text);
            jog.dec = Convert.ToDouble(this.textBox4.Text);
            jog.smooth = Convert.ToDouble(this.textBox5.Text);
            sRtn = GTN.mc.GTN_PrfJog(CORE, axis); // 设置为Jog运动模式
            sRtn = GTN.mc.GTN_SetJogPrm(CORE, axis, ref jog); // 设置Jog运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, -vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动    
            if (sRtn != 0)
                MessageBox.Show("GTN_Update" + sRtn.ToString());
        }
        private void JOG负Stop(object sender, MouseEventArgs e)
        {
            short sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 0);   // 平滑停止
            if (sRtn != 0)
                MessageBox.Show("GTN_Stop" + sRtn.ToString());
        }
        #endregion
        #region  ///初始化
        private void button1_Click(object sender, EventArgs e)
        {
            short rtn,sEcatSts;
            string strY = DateTime.Now.ToString();          
            rtn = GTN.mc.GTN_Open(5, 1);//打开运动控制器
            if (rtn != 0)
                MessageBox.Show("GTN_Open(5, 1)=" + rtn.ToString());
            rtn = GTN.mc.GTN_InitEcatComm(CORE); //初始化EtherCat总线
            if (rtn != 0)
                MessageBox.Show("GTN_InitEcatComm(CORE)=" + rtn.ToString());
          //  等待EcatCat总线初始化成功
            do
            {//读取EcatCat总线状态
                rtn = GTN.mc.GTN_IsEcatReady(CORE, out sEcatSts);
                if (rtn != 0)
                    MessageBox.Show("GTN_IsEcatReady=" + rtn.ToString());
            } while (sEcatSts != 1);

            rtn = GTN.mc.GTN_StartEcatComm(CORE);// 启动EtherCAT通讯
           if (rtn != 0)
                MessageBox.Show("GTN_StartEcatComm=" + rtn.ToString());
            string strY1 = DateTime.Now.ToString();
            MessageBox.Show(strY + "\n\r" + strY1);
            //  读取Ecat总线上的从站及轴数
            short motionCnt = 0;
            short ioCnt = 0;
            GTN.mc.TSlaveInfo slaveInfo = new GTN.mc.TSlaveInfo();
            rtn = GTN.mc.GTN_GetEcatSlaves(CORE, out motionCnt, out ioCnt);
            if (rtn != 0)
                MessageBox.Show("GGTN_GetEcatSlaves" + rtn.ToString());
            for (short i = 0; i < motionCnt + ioCnt; i++)
            {
                rtn = GTN.mc.GTN_GetEcatSlaveInfo(CORE, i, out slaveInfo);
                if (rtn != 0)
                    MessageBox.Show("GTN_GetEcatSlaves" + rtn.ToString());
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (form2 == null)
            {
                form2 = new Form2(this);
                form2.Show();
            }
            form2.flag = true;
        }
        #region////捕获回零
        private void button8_Click(object sender, EventArgs e)
        {
            int []Psts=new int[8];
            short rtn;
           // rtn = GTN.mc.GTN_LoadConfig(CORE, "GTS800.cfg");
            rtn = GTN.mc.GTN_GetSts(CORE, 1, out Psts[0], 4, out clk);
            for (short i = 1; i < 32; i++)
            {
                rtn = GTN.mc.GTN_LmtsOff(CORE, i, -1);
                rtn = GTN.mc.GTN_AlarmOff(CORE, i);
            }
            Byte op = 1;
            uint oup;
            rtn = GTN.mc.GTN_EcatSDODownload(1, 0, 10241, 0, ref op, 2, out oup);
            if (rtn != 0)
                MessageBox.Show("GTN_EcatSDODownload" + rtn.ToString());
            rtn = GTN.mc.GTN_ClrSts(CORE, 1, 32);
            if (rtn != 0)
                MessageBox.Show("GTN_ClrSts" + rtn.ToString());
            rtn = GTN.mc.GTN_GetSts(CORE, 1, out Psts[0], 8, out clk);
            if (rtn != 0)
                MessageBox.Show("GTN_GetSts" + rtn.ToString());


        }

        private void button9_Click(object sender, EventArgs e)
        {
            short rtn;
            Byte op = 1;
            uint oup;
            rtn = GTN.mc.GTN_EcatSDODownload(1, 0, (ushort)(8193 + 2048 * (axis - 1)), 0, ref op, 2, out oup);
            rtn = GTN.mc.GTN_ClrSts(CORE, 1, 32);
        }

        private void label11_Click(object sender, EventArgs e)
        {
            // 指令返回值变量
            short sRtn;
            short sEcatSts;
            short sProbePrm;        // 探针参数
            ushort usProbeSts;      // 探针捕获状态
            int iRiseValue1, iRiseValue2, iFallValue1, iFallValue2; // 探针捕获值
            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos;
            sProbePrm = 0x0001;// 探针1,2都关闭边缘捕获功能
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            sProbePrm = 0x1100; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0001) != 0)			// 探针1有效
                {
                    if ((usProbeSts & 0x0002) != 0)		// 探针1上升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);

                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                        return;
                    }
                    if ((((usProbeSts & 0x002) & (usProbeSts & 0x0200)) != 0))
                    {	// 探针2上降沿捕获触发
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);
                    }
                }
            } while (true);

        }
        #region   //回零的HOME 和Index
        private void home()
        {
            short sRtn;
            short sEcatSts;
            test4flag = false;
            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos, encposhome;
            sProbePrm = 0x0001; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            Thread.Sleep(1000);
            sProbePrm = 0x0013; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            vel = Convert.ToDouble(this.textBox1.Text);
            pos = (Int32)prfpos + Convert.ToInt32(this.textBox2.Text);
            trap.acc = Convert.ToDouble(this.textBox3.Text);
            trap.dec = Convert.ToDouble(this.textBox4.Text);
            trap.smoothTime = Convert.ToInt16(this.textBox5.Text);
            trap.velStart = 0;
            sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
            if (sRtn != 0)
                MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
            sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0001) != 0)			// 探针1有效
                {
                    if ((usProbeSts & 0x0002) != 0)		// 探针1上升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
                        pos = (int)encposhome;
                        sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 1);
                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);
                        sProbePrm = 0x0001; // 探针1上升沿连续捕获home，探针2连续捕获index
                        sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                        return;
                    }
                  
                }
                sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encpos, 1, out clk);
               
                if (encpos == pos)
                {
                    sProbePrm = 0x0001; // 探针1上升沿连续捕获home，探针2连续捕获index
                    sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                    return;
                }
            } while (true);
        }
        private void Index()
        {
            short sRtn;
            short sEcatSts;
          
            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos, encposhome;
            sProbePrm = 0x0100; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            Thread.Sleep(100);
            sProbePrm = 0x1300; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
            vel = Convert.ToDouble(this.textBox1.Text);
            pos = (int)encposhome + 10000;
            trap.acc = Convert.ToDouble(this.textBox3.Text);
            trap.dec = Convert.ToDouble(this.textBox4.Text);
            trap.smoothTime = Convert.ToInt16(this.textBox5.Text);
            trap.velStart = 0;
            sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
            if (sRtn != 0)
                MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
            sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0100) != 0)			// 探针2有效
                {
                    if ((usProbeSts & 0x0200) != 0)		// 探针2上升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
                        pos = (int)encposhome;
                        sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 1);
                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);
                        sProbePrm = 0x0100; // 探针1上升沿连续捕获home，探针2连续捕获index
                        sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                        return;
                    }
                }
                sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);
                if (homeencpos == pos)
                {
                    sProbePrm = 0x0100; // 探针1上升沿连续捕获home，探针2连续捕获index
                    sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                    return;
                }
            } while (true);
        }

        #endregion
        private void button11_Click(object sender, EventArgs e)
        {
            // 指令返回值变量
            short sRtn;
            short sEcatSts;
         
            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos;
           
            sProbePrm = 0x0013; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0001) != 0)			// 探针1有效
                {
                    if ((usProbeSts & 0x0002) != 0)		// 探针1上升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);

                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                        return;
                    }
                    if ((((usProbeSts & 0x002) & (usProbeSts & 0x0200)) != 0))
                    {	// 探针2上降沿捕获触发
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);
                    }
                }
            } while (true);
        }

        private void button12_Click(object sender, EventArgs e)
        { // 指令返回值变量
            short sRtn;
            short sEcatSts;
      
            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos;
            sProbePrm = 0x1300; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0100) != 0)			// 探针1有效
                {
                    if ((usProbeSts & 0x0200) != 0)		// 探针1上升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);

                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                        return;
                    }
                    if ((((usProbeSts & 0x002) & (usProbeSts & 0x0200)) != 0))
                    {	// 探针2上降沿捕获触发
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);
                    }
                }
            } while (true);

        }

        private void button13_Click(object sender, EventArgs e)
        {
            short sRtn, sProbePrm;
            sProbePrm = 0x0001; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            
           
        }

        private void button13_Click_1(object sender, EventArgs e)
        {///下降沿有效
            home2flag = true;
           
        }

        private void button16_Click(object sender, EventArgs e)
        {
            // 定义前瞻缓存区内存区
            short sRtn;
            GTN.mc.TCrdData[] crdData = new GTN.mc.TCrdData[200];
            System.IntPtr[] pCrdData = new IntPtr[200];
            GTN.mc.TCrdData crdDataNULL = new GTN.mc.TCrdData();
            int[] posTest = new int[2];
            int space;
            // 初始化坐标系1的FIFO0的前瞻模块
            sRtn = GTN.mc.GTN_InitLookAhead(CORE, 1, 0, 5, 1, 200, ref crdData[0]);   
               
            // 压插补数据：小线段加工
            posTest[0] = 0;
            posTest[1] = 0;
          //sRtn = GTN.mc.GTN_BufIO(CORE,1,12,1,1,0);
          // sRtn = GTN.mc.GTN_BufDelay(CORE, 1, 5000,  0);

            for (short i = 0; i < 300; ++i)
            {
                sRtn = GTN.mc.GTN_LnXY(CORE, 1, 8000 + posTest[0], 9000 + posTest[1], 20, 0.8, 0, 0);
                // 查询返回值是否成功
                //if (0 != sRtn)
                //{
                //    do
                //    {
                //        // 查询运动缓存区空间，直至空间不为0
                //        sRtn = GTN.mc.GTN_CrdSpace(CORE, 1, out space, 0);                       
                //    } while (0 == space);
                //    // 重新调用上次失败的插补指令
                //    sRtn = GTN.mc.GTN_LnXY(CORE, 1, 8000 + posTest[0], 9000 + posTest[1], 100, 0.8, 0, 0);                   
                //}
                posTest[0] += 1600;
                posTest[1] += 1850;
                if(i == 100)
                {
                    sRtn = GTN.mc.GTN_BufIO(CORE, 1, 12, 0xff, 0, 0);
                }

                if (i == 200)
                {
                    sRtn = GTN.mc.GTN_BufIO(CORE, 1, 12, 0xff, 0xff, 0);
                }

                if (i == 299)
                {
                    sRtn = GTN.mc.GTN_BufIO(CORE, 1, 12, 0xff, 0, 0);
                }
            }
          
            sRtn = GTN.mc.GTN_CrdSpace(CORE, 1,out space, 0);
            // 将前瞻缓存区中的数据压入控制器
            sRtn = GTN.mc.GTN_BufIO(CORE, 1, 12, 0xff, 0xff, 0);
            sRtn = GTN.mc.GTN_CrdData(CORE, 1, pCrdData[0], 0);
            sRtn = GTN.mc.GTN_CrdSpace(CORE,1, out space, 0);
            // 启动运动
            sRtn = GTN.mc.GTN_CrdStart(CORE, 1, 0);        
        }

        private void button17_Click(object sender, EventArgs e)
        {
            short sRtn;
            GTN.mc.TCrdPrm crdprm;
            sRtn = GTN.mc.GTN_SetCrdMapBase(CORE, 1,9);//////核1，坐标系1，从9号轴起，即profile0对应实际轴9。跨度不能超过8
            sRtn = GTN.mc.GTN_GetCrdPrm(CORE, 1, out crdprm);
            crdprm.dimension = 2;       // 坐标系为二维坐标系
            crdprm.synVelMax = 500;     // 最大合成速度：500pulse/ms
            crdprm.synAccMax = 1;       // 最大加速度：1pulse/ms^2
            crdprm.evenTime = 50;       // 最小匀速时间：50ms
            crdprm.profile1 = 1;        // 规划器1对应到X轴
            crdprm.profile2 = 2;        // 规划器2对应到Y轴
            //crdprm.profile3 = 0;
            //crdprm.profile4 = 0;
            //crdprm.profile5 = 0;
            //crdprm.profile6 = 0;
            //crdprm.profile7 =0;
            //crdprm.profile8 = 0;
            crdprm.setOriginFlag = 1;   // 需要指定坐标系的原点坐标的规划位置
            crdprm.originPos1 = 100;    // 坐标系的原点坐标的规划位置为（100, 100）
            crdprm.originPos2 = 100;    // 坐标系的原点坐标的规划位置为（100, 100）
            //crdprm.originPos3= 100;    // 坐标系的原点坐标的规划位置为（100, 100）

            //crdprm.originPos4 = 100;    // 坐标系的原点坐标的规划位置为（100, 100）
            //crdprm.originPos5 = 100;    // 坐标系的原点坐标的规划位置为（100, 100）
            //crdprm.originPos6 = 100;    // 坐标系的原点坐标的规划位置为（100, 100）
            //crdprm.originPos7 = 100;    // 坐标系的原点坐标的规划位置为（100, 100）

            //crdprm.originPos8 = 100;
            sRtn = GTN.mc.GTN_SetCrdPrm(CORE, 1, ref crdprm);
        }

        private void button18_Click(object sender, EventArgs e)
        {
        
        }

        private void button18_Click_1(object sender, EventArgs e)
        {
            short RTN;
            //for(short i=1;i<12;i++)
            //{
             RTN=  GTN.mc.GTN_RelateEcatSlaveToMcGpoBit(1,1,0,1,1,0);
            RTN = GTN.mc.GTN_RelateEcatSlaveToMcGpoBit(1, 2, 1, 0, 1, 0);//IO站
        }

        private void button19_Click(object sender, EventArgs e)
        {
            short rtn;
            //  rtn = GTN.mc.GT_SetDo(12,0x01);
            rtn=GTN.mc.GTN_SetDo(CORE,12, 0x0000);
        }

        private void button20_Click(object sender, EventArgs e)
        {
            short rtn;
            rtn= GTN.mc.GTN_SetDo(CORE, 12, 0xff);

         //   rtn = GTN.mc.GT_SetDo(12, 0x0);
        }

        private void button22_Click(object sender, EventArgs e)
        {
            short rtn;
            byte iovalue;
            ushort a = (ushort) (ECatiooffset + 2);
          //  rtn = GTN.mc.GTN_EcatIOWriteOutput(CORE, 0, ECatiooffset, Ecatsize, ref Ecatiovalue);
            rtn = GTN.mc.GTN_EcatIOReadInput(CORE, 0, a, Ecatsize, out iovalue);
            if (rtn != 0)
                MessageBox.Show("GTN_EcatIOReadInput" + rtn.ToString());
            this.textBox20.Text = iovalue.ToString();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            System.DateTime currentTime = new System.DateTime();
            string strY = DateTime.Now.ToString();
            int time,y,x;
            time = currentTime.Second;
            ThreadPool.QueueUserWorkItem(run1,"dd");
            
            string strY1 = DateTime.Now.ToString();
            MessageBox.Show(strY+ "\n\r"+strY1);
            ThreadPool.GetAvailableThreads(out  y,out x);
            MessageBox.Show(y.ToString()+"\n\r"+x.ToString());
           // Console.ReadKey();
        }
       public static void run1(object add)
        {
            Console.WriteLine("RunWorkerThread开始工作");
            Console.WriteLine("工作者线程启动成功!");
            Thread.Sleep(10000);
        }
        private void button21_Click(object sender, EventArgs e)
        {
            short rtn;           
            rtn = GTN.mc.GTN_EcatIOWriteOutput(CORE,0, ECatiooffset, Ecatsize,ref Ecatiovalue);  //输出偏移地址，字节，写入的指针
            if (rtn != 0)
                MessageBox.Show("GTN_EcatIOWriteOutput" + rtn.ToString());
        }
        private void button10_Click(object sender, EventArgs e)
        {
            // 指令返回值变量
            short sRtn;
            short sEcatSts;
        
            ushort usPreSts = 0x0000;
            short sCount = 0;
            int homeencpos=0;
            double encposhome;
            bool flag = true;
            sProbePrm = 0x0001; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            Thread.Sleep(100);
            sProbePrm = 0x0100; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            Thread.Sleep(100);
            sProbePrm = 0x1313; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);

            vel = Convert.ToDouble(this.textBox1.Text);
            pos = (Int32)prfpos + Convert.ToInt32(this.textBox2.Text);
            trap.acc = Convert.ToDouble(this.textBox3.Text);
            trap.dec = Convert.ToDouble(this.textBox4.Text);
            trap.smoothTime = Convert.ToInt16(this.textBox5.Text);
            trap.velStart = 0;
            sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
            if (sRtn != 0)
                MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
            sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动

            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                //if(((usProbeSts & 0x0002) != 0)&& ((usProbeSts & 0x0202) != 0))
                if ((usProbeSts & 0x0002) != 0)
                {
                    sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 1);
                    sProbePrm = 0x1300; // 探针1上升沿连续捕获home，探针2连续捕获index
                    sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                    sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
                    homeencpos=(int)encposhome;
                    sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
                    if (sRtn != 0)
                        MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
                    sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
                    sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
                    sRtn = GTN.mc.GTN_SetPos(CORE, axis, homeencpos + 10000);  // 设置目标位置
                    sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
                    if ((usProbeSts & 0x0202) != 0)
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
                        homeencpos = (int)encposhome;
                        sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 1);
                        Thread.Sleep(100);
                        sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
                        if (sRtn != 0)
                            MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
                        sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
                        sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
                        sRtn = GTN.mc.GTN_SetPos(CORE, axis, homeencpos);  // 设置目标位置
                        sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
                        return;
                    }
                }                
            } while (flag);
         
        }

        private void button14_Click_1(object sender, EventArgs e)
        {
            home3flag = true;
            
        }

      
   
        private void button14_Click(object sender, EventArgs e)
        {
            short sRtn, sProbePrm;
            sProbePrm = 0x0100; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);

        }

       

        private void button15_Click(object sender, EventArgs e)
        {
            test4flag = true;
            //home();
            //Index();
        }
        #endregion

        #region////清除回零后捕获边缘
        private void clrhomestatus()
        {
            short sRtn;
            short sEcatSts;
        
            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos;
            sProbePrm = 0x0101;// 探针1,2都关闭边缘捕获功能
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
        }
        #endregion
        #endregion

        #region  ///界面初始化
        private void LOAD(object sender, EventArgs e)
        {
            this.comboBox1.SelectedIndex = 0;
            test1 = new Thread(new ThreadStart(test3));
            Control.CheckForIllegalCrossThreadCalls = false;  // 解决线程间操作无效: 从不是创建控件“textBox7”的线程访问它。
            test6 = new Thread(new ThreadStart(test4));
            Control.CheckForIllegalCrossThreadCalls = false;  // 解决线程间操作无效: 从不是创建控件“textBox7”的线程访问它。
            test1.Start();//启动新线程
            test6.Start();//启动新线程

        }
        private void closed(object sender, FormClosedEventArgs e)
        {
            short rtn;
            rtn = GTN.mc.GTN_TerminateEcatComm(CORE);
            rtn = GTN.mc.GTN_Close();
            if (this.test1 != null || this.test1.IsAlive)//判断线程是否在活跃状态
            {
                this.test1.Abort(); //线程终止
                this.test1 = null;
            }
            if (this.test6 != null || this.test6.IsAlive)
            {
                this.test6.Abort();
                this.test6 = null;
            }
        }
        #endregion
        #region////线程里处理事件
        private void test3()
        {
            short sRtn;
            short sEcatSts;
            short sProbePrm;        // 探针参数
            ushort usProbeSts, usHomeSts;      // 探针捕获状态,回零状态字
            int iRiseValue1, iRiseValue2, iFallValue1, iFallValue2; // 探针捕获值
            ushort PDOoffset = 0, PDOlength = 0;
            byte PDOValue = 0;
            while (true)
            {
                axis = Convert.ToInt16(this.comboBox1.Text );
                ushort PDOoffset1 = Convert.ToUInt16(this.textBox14.Text);
             ECatiooffset = Convert.ToUInt16(this.textBox17.Text);
                Ecatsize = Convert.ToUInt16(this.textBox18.Text);
             Ecatiovalue= Convert.ToByte(this.textBox19.Text);
               // sRtn = GTN.mc.GTN_EcatIOReadInput(CORE, 0, a, Ecatsize, out iovalue);

                PDOlength = Convert.ToUInt16(this.textBox15.Text);
                if (!en[axis])
                    this.button4.Text = "伺服开启";
                else
                    this.button4.Text = "伺服关闭";
                sRtn = GTN.mc.GTN_GetPrfPos(CORE, axis, out prfpos, 1, out clk);              
                this.textBox6.Text = Math.Round(prfpos, 1).ToString();
                sRtn = GTN.mc.GTN_GetPrfVel(CORE, axis, out prfvel, 1, out clk);           
                this.textBox7.Text = Math.Round(prfvel, 1).ToString();
                sRtn = GTN.mc.GTN_GetEcatEncPos(CORE, axis, out encpos1);
                this.textBox10 .Text = encpos1.ToString();

                // sRtn = GTN.mc.GTN_GetAxisEncPos(CORE, axis, out encpos1, 1, out clk);
                sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encpos, 1, out clk);
                this.textBox8.Text = encpos.ToString();
                sRtn = GTN.mc.GTN_GetEncVel(CORE, axis, out encvel, 1, out clk);
                this.textBox9.Text = Math.Round(encvel, 1).ToString();
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);
                this.textBox11.Text = iRiseValue1.ToString();
                this.textBox12.Text = iRiseValue2.ToString();
                sRtn = GTN.mc.GTN_GetEcatHomingStatus(CORE, axis, out usHomeSts);
                this.textBox13.Text = usHomeSts.ToString();
                sRtn = GTN.mc.GTN_GetEcatRawData(CORE, PDOoffset1, PDOlength, out PDOValue);
                this.textBox16.Text = PDOValue.ToString();///读PDO的值
            }
        }
        private void test4()
        {
            short sRtn;
            while (true)
            {
                if (test4flag)
                {
                    home();
                    Index();
                    if (pos == encpos)
                        test4flag = false;
                    vel = Convert.ToDouble(this.textBox1.Text);
                  
                    trap.acc = Convert.ToDouble(this.textBox3.Text);
                    trap.dec = Convert.ToDouble(this.textBox4.Text);
                    trap.smoothTime = Convert.ToInt16(this.textBox5.Text);
                    trap.velStart = 0;
                    sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
                    if (sRtn != 0)
                        MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
                    sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
                    sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
                    sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
                    sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动

                }
                if (home2flag)
                {
                    home2();
                    Index2();
                }
                if (home3flag)
                {
                    homeEcat();
                }          
            }

        }
        #endregion

        private void button2_Click(object sender, EventArgs e)
        {
            short rtn;
            rtn = GTN.mc.GTN_Open(5, 1);
            if (rtn != 0)
            {
                Console.WriteLine("Failure to access card!\n");
                return;
            }
        }

        #region\\\ECAT轴回零
        private void homeEcat()
        {
            short sRtn;
            sRtn = GTN.mc.GTN_SetHomingMode(CORE, axis, 6);
            // 设置回零参数
            short method = 1;
            double speed1 = 48000;
            double speed2 = 48000;
            double acc = 18000;
            Int32 offset = 100;
            ushort probeFunc = 0, usHomeSts;
            sRtn = GTN.mc.GTN_SetEcatHomingPrm(CORE, axis, method, speed1, speed2, acc, offset, probeFunc);
            // 启动回零
            sRtn = GTN.mc.GTN_StartEcatHoming(CORE, axis);
            do
            {
                sRtn = GTN.mc.GTN_GetEcatHomingStatus(CORE, axis, out usHomeSts);           
               
            } while (3 != usHomeSts);   // 等待搜索原点完成
            sRtn = GTN.mc.GTN_SetHomingMode(CORE, axis, 8);	// 切换到位置控制模式
            home3flag = false;
        }

        #endregion
        #region   //回零的HOME 和Index  带高低电平选择
        private void home2()
        {
            short sRtn;
            home2flag = false;
            double  encposhome;
            sProbePrm = 0x0001; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            Thread.Sleep(1000);
            sProbePrm = 0x0023; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            vel = Convert.ToDouble(this.textBox1.Text);
            pos = (Int32)prfpos + Convert.ToInt32(this.textBox2.Text);
            trap.acc = Convert.ToDouble(this.textBox3.Text);
            trap.dec = Convert.ToDouble(this.textBox4.Text);
            trap.smoothTime = Convert.ToInt16(this.textBox5.Text);
            trap.velStart = 0;
            sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
            if (sRtn != 0)
                MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
            sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0001) != 0)			// 探针1有效
                {
                    if ((usProbeSts & 0x0004) != 0)		// 探针1下升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
                        pos = (int)encposhome;
                        sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 1);
                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);
                        sProbePrm = 0x0001; // 探针1关闭
                        sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                        return;
                    }

                }
                sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encpos, 1, out clk);

                if (encpos == pos)
                {
                    sProbePrm = 0x0001; // 探针1关闭
                    sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                    return;
                }
            } while (true);
        }
        private void Index2()
        {
            short sRtn;
            short sEcatSts;

            ushort usPreSts = 0x0001;
            short sCount = 0;
            double homeencpos, encposhome;
            sProbePrm = 0x0100; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            Thread.Sleep(100);
            sProbePrm = 0x2300; // 探针1上升沿连续捕获home，探针2连续捕获index
            sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
            sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
            vel = Convert.ToDouble(this.textBox1.Text);
            pos = (int)encposhome + 10000;
            trap.acc = Convert.ToDouble(this.textBox3.Text);
            trap.dec = Convert.ToDouble(this.textBox4.Text);
            trap.smoothTime = Convert.ToInt16(this.textBox5.Text);
            trap.velStart = 0;
            sRtn = GTN.mc.GTN_PrfTrap(CORE, axis); // 设置为点位运动模式   
            if (sRtn != 0)
                MessageBox.Show("GTN_PrfTrap" + sRtn.ToString());
            sRtn = GTN.mc.GTN_SetTrapPrm(CORE, axis, ref trap); // 设置点位运动参数
            sRtn = GTN.mc.GTN_SetVel(CORE, axis, vel);  // 设置目标速度
            sRtn = GTN.mc.GTN_SetPos(CORE, axis, pos);  // 设置目标位置
            sRtn = GTN.mc.GTN_Update(CORE, 1 << (axis - 1));    // 更新轴运动
            do
            {
                sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);

                if ((usProbeSts & 0x0100) != 0)			// 探针2有效
                {
                    if ((usProbeSts & 0x0400) != 0)		// 探针2下降升沿捕获触发
                    {
                        sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out encposhome, 1, out clk);
                        pos = (int)encposhome;
                        sRtn = GTN.mc.GTN_Stop(CORE, 1 << (axis - 1), 1);
                        sRtn = GTN.mc.GTN_GetTouchProbeStatus(CORE, axis, out usProbeSts, out iRiseValue1, out iFallValue1, out iRiseValue2, out iFallValue2);
                        sProbePrm = 0x0100; // 探针2关闭
                        sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                        return;
                    }
                }
                sRtn = GTN.mc.GTN_GetEncPos(CORE, axis, out homeencpos, 1, out clk);
                if (homeencpos == pos)
                {
                    sProbePrm = 0x0100; // 探针2关闭
                    sRtn = GTN.mc.GTN_SetTouchProbeFunction(CORE, axis, sProbePrm);
                    return;
                }
            } while (true);
        }

        #endregion
    }
}
