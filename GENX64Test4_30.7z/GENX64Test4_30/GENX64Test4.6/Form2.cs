﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GENX64Test4._6
{
    public partial class Form2 : Form
    {
        Form1 Form1;
        public bool flag;
        Control[] SCANI, outputdo,Alarm, outputdoex, SCANIex;
        uint PdiValue, PdoValue;
        short CORE = 1,station;
        byte doexValue = 0;///500协议初始值
        public Form2(Form1 ff)
        {
            InitializeComponent();
            Form1 = ff;
        }
        private void button1_Click(object sender, EventArgs e)
        {
          
        
        }

        private void load(object sender, EventArgs e)
        {
            this.comboBox1.SelectedIndex = 0;
            ControlInitial();
           // timerSANIO.Start();
        }
        private void ControlInitial()
        {
            SCANI = new Control[12] { SANI1, SANI2, SANI3, SANI4, SANI5, SANI6, SANI7, SANI8, SANI9, SANI10, SANI11, SANI12 };///通用输入
            SCANIex = new Control[16] { SCANIex0, SCANIex1, SCANIex2, SCANIex3, SCANIex4, SCANIex5, SCANIex6, SCANIex7, SCANIex8, SCANIex9, SCANIex10, SCANIex11, SCANIex12, SCANIex13, SCANIex14, SCANIex15};///通用输入
            Alarm = new Control[18] { Alarm0, Alarm1, Alarm2, Alarm3, Alarm4, Alarm5, Alarm6, Alarm7, Alarm8, Alarm9,Alarm10,Alarm11,Alarm12,Alarm13,Alarm14,Alarm15,Alarm16,Alarm17 };
            outputdoex = new Control[16] { outputdoex0, outputdoex1, outputdoex2, outputdoex3, outputdoex4, outputdoex5, outputdoex6, outputdoex7, outputdoex8, outputdoex9, outputdoex10, outputdoex11, outputdoex12, outputdoex13, outputdoex14, outputdoex15 };///通用输出
            outputdo = new Control[16] { output0, output1, output2, output3, output4, output5, output6, output7, output8, output9, output10, output11, output12, output13, output14, output15 };///通用输出
        }
        #region////定时器所做事
        private void timerSANIO_Tick(object sender, EventArgs e)
        {
            short rtn;
            station = Convert.ToInt16(this.comboBox1.Text);
            rtn = GTN.mc.GTN_GetEcatAxisDI(CORE, 1, out PdiValue);
            rtn = GTN.mc.GTN_GetEcatAxisDO(CORE, 1, out PdoValue);
            this.textBox1.Text = PdiValue.ToString();
            this.textBox2.Text = PdoValue.ToString();
            timerdi();
            timeralarm();
            timerDO();
            timerdiex();
            timerdoex();

        }
        #endregion
        #region/////////di检测
        private void timerdi()
        {
            for (int i = 0; i < 12; i++)                                        //比如10进制的8              1000
            {                                                                   //移位然后按位比较 i=0时，   0000         按位&后等于0000即为0
                if ((PdiValue & (1 << (i+18))) != 0)                                        //移位然后按位比较 i=3时，   1000         按位&后等于1000即为8
                {
                    SCANI[i].BackColor = Color.LightGreen;
                    SCANI[i].ForeColor = Color.Black;
                }
                else
                {
                    SCANI[i].BackColor = Color.LightGray;
                    SCANI[i].ForeColor = Color.Black;
                }
            }
        }
        private void timerdiex()
        {
            short rtn;
            byte exdidata;
            ushort length=2;
          
            for (int i = 0; i < 16; i++)                                       
            {
                if (i < 8)
                {
                    rtn = GTN.glink.GT_GetGLinkDi(station, 0, out exdidata, length);
                    textBox3.Text = exdidata.ToString();
                    if ((exdidata & (1 << (i))) != 0)
                    {
                        SCANIex[i].BackColor = Color.LightGreen;
                        SCANIex[i].ForeColor = Color.Black;
                    }
                    else
                    {
                        SCANIex[i].BackColor = Color.LightGray;
                        SCANIex[i].ForeColor = Color.Black;
                    }
                }
                else
                {
                    rtn = GTN.glink.GT_GetGLinkDi(station, 1, out exdidata, length);
                    textBox3.Text = exdidata.ToString();
                    if ((exdidata & (1 << (i-8))) != 0)
                    {
                        SCANIex[i].BackColor = Color.LightGreen;
                        SCANIex[i].ForeColor = Color.Black;
                    }
                    else
                    {
                        SCANIex[i].BackColor = Color.LightGray;
                        SCANIex[i].ForeColor = Color.Black;
                    }
                }                                                             
               
            }

        }

       
        #endregion

        #region/////////6轴HOME、limit
        private void timeralarm()
        {
            for (int i = 0; i <18; i++)                                        //比如10进制的8              1000
            {                                                                   //移位然后按位比较 i=0时，   0000         按位&后等于0000即为0
                if ((PdiValue & (1 << i )) != 0)                                        //移位然后按位比较 i=3时，   1000         按位&后等于1000即为8
                {
                    Alarm[i].BackColor = Color.LightGreen;
                    Alarm[i].ForeColor = Color.Black;
                }
                else
                {
                    Alarm[i].BackColor = Color.LightGray;
                    Alarm[i].ForeColor = Color.Black;
                }
            }
        }

       
        #endregion

        #region/////////6轴DO和500协议
        private void timerDO()
        {
            short rStn;
            rStn = GTN.mc.GT_GetEcatAxisDO(1, out PdoValue);
            for (int i = 0; i < 16; i++)
            {
                if ((PdoValue & (1 << i)) != 0)
                {
                    outputdo[i].BackColor = Color.LightGray;
                }
                else
                {
                    outputdo[i].BackColor = Color.LightGreen;
                }

            }
        }
        private void timerdoex()
        {
            short rStn;
         
            ushort length = 2;
            rStn = GTN.glink.GT_GetGLinkDo(station,1,ref doexValue,length);
            for (int i = 0; i < 16; i++)
            {
                if (i < 8)
                {
                    rStn = GTN.glink.GT_GetGLinkDo(station, 0, ref doexValue, length);
                    if ((doexValue & (1 << i)) != 0)
                    {
                        outputdoex[i].BackColor = Color.LightGray;
                    }
                    else
                    {
                        outputdoex[i].BackColor = Color.LightGreen;
                    }

                }
                else
                {
                    rStn = GTN.glink.GT_GetGLinkDo(station, 1, ref doexValue, length);
                    if ((doexValue & (1 << i-8)) != 0)
                    {
                        outputdoex[i].BackColor = Color.LightGray;
                    }
                    else
                    {
                        outputdoex[i].BackColor = Color.LightGreen;
                    }
                }
            }
            textBox4.Text = doexValue.ToString();
        }
        #endregion
        #region/////do按键处理
        private void output0_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[0].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 0, 1);
            }
            else
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 0, 0);
            }

        }
        private void output1_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[1].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 1, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 1, 0);

            }
        }
        private void output2_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[2].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 2, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 2, 0);

            }

        }

        private void output6_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[6].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 6, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 6, 0);

            }

        }

        private void outputdoex0_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[0].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 0,1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 0, 0);
            }
        }

        private void outputdoex1_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[1].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 1, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 1, 0);
            }
        }

        private void outputdoex2_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[2].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 2, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 2, 0);
            }
        }

        private void outputdoex3_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[3].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 3, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 3, 0);
            }
        }

        private void outputdoex4_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[4].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 4, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 4, 0);
            }
        }

        private void outputdoex5_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[5].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 5, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 5, 0);
            }
        }

        private void outputdoex6_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[6].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 6, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 6, 0);
            }
        }

        private void outputdoex7_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[7].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 7, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 7, 0);
            }
        }

        private void outputdoex8_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[8].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 8, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 8, 0);
            }
        }

        private void outputdoex9_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[9].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 9, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 9, 0);
            }
        }

        private void outputdoex10_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[10].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station,10, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 10, 0);
            }
        }

        private void outputdoex11_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[11].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 11, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 11, 0);
            }
        }

        private void outputdoex12_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[12].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 12, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 12, 0);
            }
        }

        private void outputdoex13_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[13].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 13, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 13, 0);
            }
        }

        private void outputdoex14_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[14].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 14, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 14, 0);
            }
        }

        private void outputdoex15_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdoex[15].BackColor == Color.LightGreen)
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 15, 1);
            }
            else
            {
                rtn = GTN.glink.GT_SetGLinkDoBit(station, 15, 0);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            short rtn;
            byte slavenum;
            rtn = GTN.glink.GT_GLinkInit(0);///初始化模块
            if (rtn == 0)
            {
                rtn = GTN.glink. GT_GetGLinkOnlineSlaveNum(out slavenum);              
                MessageBox.Show(slavenum + ("个模块初始化成功！"));
            }
            timerSANIO.Start();
        }

        private void closed(object sender, FormClosedEventArgs e)
        {
            Form1.form2 = null;///退出form时将form置null,以便下次通过切换按键进到该界面
        }

        private void output7_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[7].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 7, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 7, 0);

            }
        }

        private void output3_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[3].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 3, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 3, 0);

            }

        }
        private void output4_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[4].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 4, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 4, 0);

            }

        }
        private void output5_Click(object sender, EventArgs e)
        {
            short rtn;
            if (outputdo[5].BackColor == Color.LightGreen)
            {
                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 5, 1);
            }
            else
            {

                rtn = GTN.mc.GTN_SetEcatAxisDOBit(CORE, 1, 5, 0);

            }

        }
        #endregion
    }
}
