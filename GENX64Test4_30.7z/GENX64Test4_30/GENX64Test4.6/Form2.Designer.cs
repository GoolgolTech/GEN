﻿namespace GENX64Test4._6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.timerSANIO = new System.Windows.Forms.Timer(this.components);
            this.SANI5 = new System.Windows.Forms.Label();
            this.SANI1 = new System.Windows.Forms.Label();
            this.SANI2 = new System.Windows.Forms.Label();
            this.SANI8 = new System.Windows.Forms.Label();
            this.SANI9 = new System.Windows.Forms.Label();
            this.SANI3 = new System.Windows.Forms.Label();
            this.SANI7 = new System.Windows.Forms.Label();
            this.SANI10 = new System.Windows.Forms.Label();
            this.SANI4 = new System.Windows.Forms.Label();
            this.SANI6 = new System.Windows.Forms.Label();
            this.SANI11 = new System.Windows.Forms.Label();
            this.SANI12 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Alarm10 = new System.Windows.Forms.Button();
            this.Alarm7 = new System.Windows.Forms.Button();
            this.Alarm16 = new System.Windows.Forms.Button();
            this.Alarm4 = new System.Windows.Forms.Button();
            this.Alarm9 = new System.Windows.Forms.Button();
            this.Alarm6 = new System.Windows.Forms.Button();
            this.Alarm15 = new System.Windows.Forms.Button();
            this.Alarm3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.output15 = new System.Windows.Forms.Button();
            this.output7 = new System.Windows.Forms.Button();
            this.output14 = new System.Windows.Forms.Button();
            this.output6 = new System.Windows.Forms.Button();
            this.output13 = new System.Windows.Forms.Button();
            this.output5 = new System.Windows.Forms.Button();
            this.output12 = new System.Windows.Forms.Button();
            this.output4 = new System.Windows.Forms.Button();
            this.output11 = new System.Windows.Forms.Button();
            this.output3 = new System.Windows.Forms.Button();
            this.output10 = new System.Windows.Forms.Button();
            this.output2 = new System.Windows.Forms.Button();
            this.output9 = new System.Windows.Forms.Button();
            this.output1 = new System.Windows.Forms.Button();
            this.Alarm13 = new System.Windows.Forms.Button();
            this.Alarm1 = new System.Windows.Forms.Button();
            this.Alarm17 = new System.Windows.Forms.Button();
            this.Alarm14 = new System.Windows.Forms.Button();
            this.Alarm11 = new System.Windows.Forms.Button();
            this.Alarm8 = new System.Windows.Forms.Button();
            this.Alarm5 = new System.Windows.Forms.Button();
            this.Alarm2 = new System.Windows.Forms.Button();
            this.Alarm12 = new System.Windows.Forms.Button();
            this.Alarm0 = new System.Windows.Forms.Button();
            this.output8 = new System.Windows.Forms.Button();
            this.output0 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.outputdoex15 = new System.Windows.Forms.Button();
            this.outputdoex7 = new System.Windows.Forms.Button();
            this.outputdoex14 = new System.Windows.Forms.Button();
            this.outputdoex6 = new System.Windows.Forms.Button();
            this.outputdoex13 = new System.Windows.Forms.Button();
            this.outputdoex5 = new System.Windows.Forms.Button();
            this.outputdoex12 = new System.Windows.Forms.Button();
            this.outputdoex4 = new System.Windows.Forms.Button();
            this.outputdoex11 = new System.Windows.Forms.Button();
            this.outputdoex3 = new System.Windows.Forms.Button();
            this.outputdoex10 = new System.Windows.Forms.Button();
            this.outputdoex2 = new System.Windows.Forms.Button();
            this.outputdoex9 = new System.Windows.Forms.Button();
            this.outputdoex1 = new System.Windows.Forms.Button();
            this.outputdoex8 = new System.Windows.Forms.Button();
            this.outputdoex0 = new System.Windows.Forms.Button();
            this.SCANIex4 = new System.Windows.Forms.Label();
            this.SCANIex0 = new System.Windows.Forms.Label();
            this.SCANIex15 = new System.Windows.Forms.Label();
            this.SCANIex1 = new System.Windows.Forms.Label();
            this.SCANIex7 = new System.Windows.Forms.Label();
            this.SCANIex8 = new System.Windows.Forms.Label();
            this.SCANIex14 = new System.Windows.Forms.Label();
            this.SCANIex2 = new System.Windows.Forms.Label();
            this.SCANIex6 = new System.Windows.Forms.Label();
            this.SCANIex9 = new System.Windows.Forms.Label();
            this.SCANIex13 = new System.Windows.Forms.Label();
            this.SCANIex3 = new System.Windows.Forms.Label();
            this.SCANIex5 = new System.Windows.Forms.Label();
            this.SCANIex10 = new System.Windows.Forms.Label();
            this.SCANIex12 = new System.Windows.Forms.Label();
            this.SCANIex11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(798, 548);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 64);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timerSANIO
            // 
            this.timerSANIO.Tick += new System.EventHandler(this.timerSANIO_Tick);
            // 
            // SANI5
            // 
            this.SANI5.BackColor = System.Drawing.Color.LightGray;
            this.SANI5.Location = new System.Drawing.Point(448, 56);
            this.SANI5.Name = "SANI5";
            this.SANI5.Size = new System.Drawing.Size(86, 22);
            this.SANI5.TabIndex = 2;
            this.SANI5.Text = "  DI4";
            // 
            // SANI1
            // 
            this.SANI1.BackColor = System.Drawing.Color.LightGray;
            this.SANI1.Location = new System.Drawing.Point(18, 56);
            this.SANI1.Name = "SANI1";
            this.SANI1.Size = new System.Drawing.Size(86, 22);
            this.SANI1.TabIndex = 3;
            this.SANI1.Text = "  DI0";
            // 
            // SANI2
            // 
            this.SANI2.BackColor = System.Drawing.Color.LightGray;
            this.SANI2.Location = new System.Drawing.Point(118, 56);
            this.SANI2.Name = "SANI2";
            this.SANI2.Size = new System.Drawing.Size(86, 22);
            this.SANI2.TabIndex = 5;
            this.SANI2.Text = "  DI1";
            // 
            // SANI8
            // 
            this.SANI8.BackColor = System.Drawing.Color.LightGray;
            this.SANI8.Location = new System.Drawing.Point(118, 92);
            this.SANI8.Name = "SANI8";
            this.SANI8.Size = new System.Drawing.Size(86, 22);
            this.SANI8.TabIndex = 6;
            this.SANI8.Text = "  DI7";
            // 
            // SANI9
            // 
            this.SANI9.BackColor = System.Drawing.Color.LightGray;
            this.SANI9.Location = new System.Drawing.Point(230, 90);
            this.SANI9.Name = "SANI9";
            this.SANI9.Size = new System.Drawing.Size(86, 22);
            this.SANI9.TabIndex = 7;
            this.SANI9.Text = "  DI8";
            // 
            // SANI3
            // 
            this.SANI3.BackColor = System.Drawing.Color.LightGray;
            this.SANI3.Location = new System.Drawing.Point(230, 56);
            this.SANI3.Name = "SANI3";
            this.SANI3.Size = new System.Drawing.Size(86, 22);
            this.SANI3.TabIndex = 9;
            this.SANI3.Text = "  DI2";
            // 
            // SANI7
            // 
            this.SANI7.BackColor = System.Drawing.Color.LightGray;
            this.SANI7.Location = new System.Drawing.Point(18, 92);
            this.SANI7.Name = "SANI7";
            this.SANI7.Size = new System.Drawing.Size(86, 22);
            this.SANI7.TabIndex = 10;
            this.SANI7.Text = "  DI6";
            // 
            // SANI10
            // 
            this.SANI10.BackColor = System.Drawing.Color.LightGray;
            this.SANI10.Location = new System.Drawing.Point(334, 92);
            this.SANI10.Name = "SANI10";
            this.SANI10.Size = new System.Drawing.Size(86, 22);
            this.SANI10.TabIndex = 11;
            this.SANI10.Text = "  DI9";
            // 
            // SANI4
            // 
            this.SANI4.BackColor = System.Drawing.Color.LightGray;
            this.SANI4.Location = new System.Drawing.Point(334, 56);
            this.SANI4.Name = "SANI4";
            this.SANI4.Size = new System.Drawing.Size(86, 22);
            this.SANI4.TabIndex = 13;
            this.SANI4.Text = "  DI3";
            // 
            // SANI6
            // 
            this.SANI6.BackColor = System.Drawing.Color.LightGray;
            this.SANI6.Location = new System.Drawing.Point(550, 56);
            this.SANI6.Name = "SANI6";
            this.SANI6.Size = new System.Drawing.Size(86, 22);
            this.SANI6.TabIndex = 14;
            this.SANI6.Text = "  DI5";
            // 
            // SANI11
            // 
            this.SANI11.BackColor = System.Drawing.Color.LightGray;
            this.SANI11.Location = new System.Drawing.Point(436, 90);
            this.SANI11.Name = "SANI11";
            this.SANI11.Size = new System.Drawing.Size(86, 22);
            this.SANI11.TabIndex = 15;
            this.SANI11.Text = "  DI10";
            // 
            // SANI12
            // 
            this.SANI12.BackColor = System.Drawing.Color.LightGray;
            this.SANI12.Location = new System.Drawing.Point(546, 92);
            this.SANI12.Name = "SANI12";
            this.SANI12.Size = new System.Drawing.Size(86, 22);
            this.SANI12.TabIndex = 17;
            this.SANI12.Text = "  DI11";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 21);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1179, 495);
            this.tabControl1.TabIndex = 18;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.Alarm10);
            this.tabPage1.Controls.Add(this.Alarm7);
            this.tabPage1.Controls.Add(this.Alarm16);
            this.tabPage1.Controls.Add(this.Alarm4);
            this.tabPage1.Controls.Add(this.Alarm9);
            this.tabPage1.Controls.Add(this.Alarm6);
            this.tabPage1.Controls.Add(this.Alarm15);
            this.tabPage1.Controls.Add(this.Alarm3);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.output15);
            this.tabPage1.Controls.Add(this.output7);
            this.tabPage1.Controls.Add(this.output14);
            this.tabPage1.Controls.Add(this.output6);
            this.tabPage1.Controls.Add(this.output13);
            this.tabPage1.Controls.Add(this.output5);
            this.tabPage1.Controls.Add(this.output12);
            this.tabPage1.Controls.Add(this.output4);
            this.tabPage1.Controls.Add(this.output11);
            this.tabPage1.Controls.Add(this.output3);
            this.tabPage1.Controls.Add(this.output10);
            this.tabPage1.Controls.Add(this.output2);
            this.tabPage1.Controls.Add(this.output9);
            this.tabPage1.Controls.Add(this.output1);
            this.tabPage1.Controls.Add(this.Alarm13);
            this.tabPage1.Controls.Add(this.Alarm1);
            this.tabPage1.Controls.Add(this.Alarm17);
            this.tabPage1.Controls.Add(this.Alarm14);
            this.tabPage1.Controls.Add(this.Alarm11);
            this.tabPage1.Controls.Add(this.Alarm8);
            this.tabPage1.Controls.Add(this.Alarm5);
            this.tabPage1.Controls.Add(this.Alarm2);
            this.tabPage1.Controls.Add(this.Alarm12);
            this.tabPage1.Controls.Add(this.Alarm0);
            this.tabPage1.Controls.Add(this.output8);
            this.tabPage1.Controls.Add(this.output0);
            this.tabPage1.Controls.Add(this.SANI1);
            this.tabPage1.Controls.Add(this.SANI5);
            this.tabPage1.Controls.Add(this.SANI12);
            this.tabPage1.Controls.Add(this.SANI11);
            this.tabPage1.Controls.Add(this.SANI2);
            this.tabPage1.Controls.Add(this.SANI6);
            this.tabPage1.Controls.Add(this.SANI8);
            this.tabPage1.Controls.Add(this.SANI4);
            this.tabPage1.Controls.Add(this.SANI9);
            this.tabPage1.Controls.Add(this.SANI10);
            this.tabPage1.Controls.Add(this.SANI3);
            this.tabPage1.Controls.Add(this.SANI7);
            this.tabPage1.Location = new System.Drawing.Point(4, 28);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage1.Size = new System.Drawing.Size(1171, 463);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "6轴ECAT模块IO";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(360, 400);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(148, 28);
            this.textBox2.TabIndex = 37;
            // 
            // Alarm10
            // 
            this.Alarm10.Location = new System.Drawing.Point(118, 284);
            this.Alarm10.Name = "Alarm10";
            this.Alarm10.Size = new System.Drawing.Size(86, 40);
            this.Alarm10.TabIndex = 35;
            this.Alarm10.Text = "Limit3+";
            this.Alarm10.UseVisualStyleBackColor = true;
            // 
            // Alarm7
            // 
            this.Alarm7.Location = new System.Drawing.Point(554, 238);
            this.Alarm7.Name = "Alarm7";
            this.Alarm7.Size = new System.Drawing.Size(86, 40);
            this.Alarm7.TabIndex = 35;
            this.Alarm7.Text = "Limit2+";
            this.Alarm7.UseVisualStyleBackColor = true;
            // 
            // Alarm16
            // 
            this.Alarm16.Location = new System.Drawing.Point(554, 284);
            this.Alarm16.Name = "Alarm16";
            this.Alarm16.Size = new System.Drawing.Size(86, 40);
            this.Alarm16.TabIndex = 35;
            this.Alarm16.Text = "Limit5+";
            this.Alarm16.UseVisualStyleBackColor = true;
            // 
            // Alarm4
            // 
            this.Alarm4.Location = new System.Drawing.Point(334, 238);
            this.Alarm4.Name = "Alarm4";
            this.Alarm4.Size = new System.Drawing.Size(86, 40);
            this.Alarm4.TabIndex = 35;
            this.Alarm4.Text = "Limit1+";
            this.Alarm4.UseVisualStyleBackColor = true;
            // 
            // Alarm9
            // 
            this.Alarm9.Location = new System.Drawing.Point(18, 284);
            this.Alarm9.Name = "Alarm9";
            this.Alarm9.Size = new System.Drawing.Size(86, 40);
            this.Alarm9.TabIndex = 36;
            this.Alarm9.Text = "Limit3-";
            this.Alarm9.UseVisualStyleBackColor = true;
            // 
            // Alarm6
            // 
            this.Alarm6.Location = new System.Drawing.Point(452, 238);
            this.Alarm6.Name = "Alarm6";
            this.Alarm6.Size = new System.Drawing.Size(86, 40);
            this.Alarm6.TabIndex = 36;
            this.Alarm6.Text = "Limit2-";
            this.Alarm6.UseVisualStyleBackColor = true;
            // 
            // Alarm15
            // 
            this.Alarm15.Location = new System.Drawing.Point(452, 284);
            this.Alarm15.Name = "Alarm15";
            this.Alarm15.Size = new System.Drawing.Size(86, 40);
            this.Alarm15.TabIndex = 36;
            this.Alarm15.Text = "Limit5-";
            this.Alarm15.UseVisualStyleBackColor = true;
            // 
            // Alarm3
            // 
            this.Alarm3.Location = new System.Drawing.Point(230, 238);
            this.Alarm3.Name = "Alarm3";
            this.Alarm3.Size = new System.Drawing.Size(86, 40);
            this.Alarm3.TabIndex = 36;
            this.Alarm3.Text = "Limit1-";
            this.Alarm3.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(196, 402);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 28);
            this.textBox1.TabIndex = 34;
            // 
            // output15
            // 
            this.output15.Location = new System.Drawing.Point(816, 176);
            this.output15.Name = "output15";
            this.output15.Size = new System.Drawing.Size(86, 40);
            this.output15.TabIndex = 18;
            this.output15.Text = "DO 15";
            this.output15.UseVisualStyleBackColor = true;
            // 
            // output7
            // 
            this.output7.Location = new System.Drawing.Point(816, 129);
            this.output7.Name = "output7";
            this.output7.Size = new System.Drawing.Size(86, 40);
            this.output7.TabIndex = 19;
            this.output7.Text = "DO 7";
            this.output7.UseVisualStyleBackColor = true;
            this.output7.Click += new System.EventHandler(this.output7_Click);
            // 
            // output14
            // 
            this.output14.Location = new System.Drawing.Point(684, 176);
            this.output14.Name = "output14";
            this.output14.Size = new System.Drawing.Size(86, 40);
            this.output14.TabIndex = 20;
            this.output14.Text = "DO 14";
            this.output14.UseVisualStyleBackColor = true;
            // 
            // output6
            // 
            this.output6.Location = new System.Drawing.Point(684, 129);
            this.output6.Name = "output6";
            this.output6.Size = new System.Drawing.Size(86, 40);
            this.output6.TabIndex = 21;
            this.output6.Text = "DO 6";
            this.output6.UseVisualStyleBackColor = true;
            this.output6.Click += new System.EventHandler(this.output6_Click);
            // 
            // output13
            // 
            this.output13.Location = new System.Drawing.Point(554, 176);
            this.output13.Name = "output13";
            this.output13.Size = new System.Drawing.Size(86, 40);
            this.output13.TabIndex = 22;
            this.output13.Text = "DO 13";
            this.output13.UseVisualStyleBackColor = true;
            // 
            // output5
            // 
            this.output5.Location = new System.Drawing.Point(554, 129);
            this.output5.Name = "output5";
            this.output5.Size = new System.Drawing.Size(86, 40);
            this.output5.TabIndex = 23;
            this.output5.Text = "DO 5";
            this.output5.UseVisualStyleBackColor = true;
            this.output5.Click += new System.EventHandler(this.output5_Click);
            // 
            // output12
            // 
            this.output12.Location = new System.Drawing.Point(450, 176);
            this.output12.Name = "output12";
            this.output12.Size = new System.Drawing.Size(86, 40);
            this.output12.TabIndex = 24;
            this.output12.Text = "DO 12";
            this.output12.UseVisualStyleBackColor = true;
            // 
            // output4
            // 
            this.output4.Location = new System.Drawing.Point(450, 129);
            this.output4.Name = "output4";
            this.output4.Size = new System.Drawing.Size(86, 40);
            this.output4.TabIndex = 25;
            this.output4.Text = "DO 4";
            this.output4.UseVisualStyleBackColor = true;
            this.output4.Click += new System.EventHandler(this.output4_Click);
            // 
            // output11
            // 
            this.output11.Location = new System.Drawing.Point(334, 176);
            this.output11.Name = "output11";
            this.output11.Size = new System.Drawing.Size(86, 40);
            this.output11.TabIndex = 26;
            this.output11.Text = "DO 11";
            this.output11.UseVisualStyleBackColor = true;
            // 
            // output3
            // 
            this.output3.Location = new System.Drawing.Point(334, 129);
            this.output3.Name = "output3";
            this.output3.Size = new System.Drawing.Size(86, 40);
            this.output3.TabIndex = 27;
            this.output3.Text = "DO 3";
            this.output3.UseVisualStyleBackColor = true;
            this.output3.Click += new System.EventHandler(this.output3_Click);
            // 
            // output10
            // 
            this.output10.Location = new System.Drawing.Point(230, 176);
            this.output10.Name = "output10";
            this.output10.Size = new System.Drawing.Size(86, 40);
            this.output10.TabIndex = 28;
            this.output10.Text = "DO 10";
            this.output10.UseVisualStyleBackColor = true;
            // 
            // output2
            // 
            this.output2.Location = new System.Drawing.Point(230, 129);
            this.output2.Name = "output2";
            this.output2.Size = new System.Drawing.Size(86, 40);
            this.output2.TabIndex = 29;
            this.output2.Text = "DO 2";
            this.output2.UseVisualStyleBackColor = true;
            this.output2.Click += new System.EventHandler(this.output2_Click);
            // 
            // output9
            // 
            this.output9.Location = new System.Drawing.Point(118, 176);
            this.output9.Name = "output9";
            this.output9.Size = new System.Drawing.Size(86, 40);
            this.output9.TabIndex = 30;
            this.output9.Text = "DO 9";
            this.output9.UseVisualStyleBackColor = true;
            // 
            // output1
            // 
            this.output1.Location = new System.Drawing.Point(118, 129);
            this.output1.Name = "output1";
            this.output1.Size = new System.Drawing.Size(86, 40);
            this.output1.TabIndex = 31;
            this.output1.Text = "DO 1";
            this.output1.UseVisualStyleBackColor = true;
            this.output1.Click += new System.EventHandler(this.output1_Click);
            // 
            // Alarm13
            // 
            this.Alarm13.Location = new System.Drawing.Point(334, 284);
            this.Alarm13.Name = "Alarm13";
            this.Alarm13.Size = new System.Drawing.Size(86, 40);
            this.Alarm13.TabIndex = 32;
            this.Alarm13.Text = "Limit4+";
            this.Alarm13.UseVisualStyleBackColor = true;
            // 
            // Alarm1
            // 
            this.Alarm1.Location = new System.Drawing.Point(118, 238);
            this.Alarm1.Name = "Alarm1";
            this.Alarm1.Size = new System.Drawing.Size(86, 40);
            this.Alarm1.TabIndex = 32;
            this.Alarm1.Text = "Limit0+";
            this.Alarm1.UseVisualStyleBackColor = true;
            // 
            // Alarm17
            // 
            this.Alarm17.Location = new System.Drawing.Point(554, 340);
            this.Alarm17.Name = "Alarm17";
            this.Alarm17.Size = new System.Drawing.Size(86, 40);
            this.Alarm17.TabIndex = 32;
            this.Alarm17.Text = "HOME5";
            this.Alarm17.UseVisualStyleBackColor = true;
            // 
            // Alarm14
            // 
            this.Alarm14.Location = new System.Drawing.Point(452, 340);
            this.Alarm14.Name = "Alarm14";
            this.Alarm14.Size = new System.Drawing.Size(86, 40);
            this.Alarm14.TabIndex = 32;
            this.Alarm14.Text = "HOME4";
            this.Alarm14.UseVisualStyleBackColor = true;
            // 
            // Alarm11
            // 
            this.Alarm11.Location = new System.Drawing.Point(334, 340);
            this.Alarm11.Name = "Alarm11";
            this.Alarm11.Size = new System.Drawing.Size(86, 40);
            this.Alarm11.TabIndex = 32;
            this.Alarm11.Text = "HOME3";
            this.Alarm11.UseVisualStyleBackColor = true;
            // 
            // Alarm8
            // 
            this.Alarm8.Location = new System.Drawing.Point(230, 340);
            this.Alarm8.Name = "Alarm8";
            this.Alarm8.Size = new System.Drawing.Size(86, 40);
            this.Alarm8.TabIndex = 32;
            this.Alarm8.Text = "HOME2";
            this.Alarm8.UseVisualStyleBackColor = true;
            // 
            // Alarm5
            // 
            this.Alarm5.Location = new System.Drawing.Point(118, 340);
            this.Alarm5.Name = "Alarm5";
            this.Alarm5.Size = new System.Drawing.Size(86, 40);
            this.Alarm5.TabIndex = 32;
            this.Alarm5.Text = "HOME1";
            this.Alarm5.UseVisualStyleBackColor = true;
            // 
            // Alarm2
            // 
            this.Alarm2.Location = new System.Drawing.Point(18, 340);
            this.Alarm2.Name = "Alarm2";
            this.Alarm2.Size = new System.Drawing.Size(86, 40);
            this.Alarm2.TabIndex = 32;
            this.Alarm2.Text = "HOME0";
            this.Alarm2.UseVisualStyleBackColor = true;
            // 
            // Alarm12
            // 
            this.Alarm12.Location = new System.Drawing.Point(230, 284);
            this.Alarm12.Name = "Alarm12";
            this.Alarm12.Size = new System.Drawing.Size(86, 40);
            this.Alarm12.TabIndex = 32;
            this.Alarm12.Text = "Limit4-";
            this.Alarm12.UseVisualStyleBackColor = true;
            // 
            // Alarm0
            // 
            this.Alarm0.Location = new System.Drawing.Point(18, 238);
            this.Alarm0.Name = "Alarm0";
            this.Alarm0.Size = new System.Drawing.Size(86, 40);
            this.Alarm0.TabIndex = 32;
            this.Alarm0.Text = "Limit0-";
            this.Alarm0.UseVisualStyleBackColor = true;
            // 
            // output8
            // 
            this.output8.Location = new System.Drawing.Point(18, 176);
            this.output8.Name = "output8";
            this.output8.Size = new System.Drawing.Size(86, 40);
            this.output8.TabIndex = 32;
            this.output8.Text = "DO 8";
            this.output8.UseVisualStyleBackColor = true;
            // 
            // output0
            // 
            this.output0.Location = new System.Drawing.Point(18, 129);
            this.output0.Name = "output0";
            this.output0.Size = new System.Drawing.Size(86, 40);
            this.output0.TabIndex = 33;
            this.output0.Text = "DO 0";
            this.output0.UseVisualStyleBackColor = true;
            this.output0.Click += new System.EventHandler(this.output0_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.textBox4);
            this.tabPage2.Controls.Add(this.textBox3);
            this.tabPage2.Controls.Add(this.outputdoex15);
            this.tabPage2.Controls.Add(this.outputdoex7);
            this.tabPage2.Controls.Add(this.outputdoex14);
            this.tabPage2.Controls.Add(this.outputdoex6);
            this.tabPage2.Controls.Add(this.outputdoex13);
            this.tabPage2.Controls.Add(this.outputdoex5);
            this.tabPage2.Controls.Add(this.outputdoex12);
            this.tabPage2.Controls.Add(this.outputdoex4);
            this.tabPage2.Controls.Add(this.outputdoex11);
            this.tabPage2.Controls.Add(this.outputdoex3);
            this.tabPage2.Controls.Add(this.outputdoex10);
            this.tabPage2.Controls.Add(this.outputdoex2);
            this.tabPage2.Controls.Add(this.outputdoex9);
            this.tabPage2.Controls.Add(this.outputdoex1);
            this.tabPage2.Controls.Add(this.outputdoex8);
            this.tabPage2.Controls.Add(this.outputdoex0);
            this.tabPage2.Controls.Add(this.SCANIex4);
            this.tabPage2.Controls.Add(this.SCANIex0);
            this.tabPage2.Controls.Add(this.SCANIex15);
            this.tabPage2.Controls.Add(this.SCANIex1);
            this.tabPage2.Controls.Add(this.SCANIex7);
            this.tabPage2.Controls.Add(this.SCANIex8);
            this.tabPage2.Controls.Add(this.SCANIex14);
            this.tabPage2.Controls.Add(this.SCANIex2);
            this.tabPage2.Controls.Add(this.SCANIex6);
            this.tabPage2.Controls.Add(this.SCANIex9);
            this.tabPage2.Controls.Add(this.SCANIex13);
            this.tabPage2.Controls.Add(this.SCANIex3);
            this.tabPage2.Controls.Add(this.SCANIex5);
            this.tabPage2.Controls.Add(this.SCANIex10);
            this.tabPage2.Controls.Add(this.SCANIex12);
            this.tabPage2.Controls.Add(this.SCANIex11);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.comboBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 28);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
            this.tabPage2.Size = new System.Drawing.Size(1171, 463);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "500协议扩展模块";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(530, 24);
            this.textBox4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(148, 28);
            this.textBox4.TabIndex = 36;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(398, 26);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 28);
            this.textBox3.TabIndex = 35;
            // 
            // outputdoex15
            // 
            this.outputdoex15.Location = new System.Drawing.Point(860, 196);
            this.outputdoex15.Name = "outputdoex15";
            this.outputdoex15.Size = new System.Drawing.Size(86, 40);
            this.outputdoex15.TabIndex = 19;
            this.outputdoex15.Text = "DO 15";
            this.outputdoex15.UseVisualStyleBackColor = true;
            this.outputdoex15.Click += new System.EventHandler(this.outputdoex15_Click);
            // 
            // outputdoex7
            // 
            this.outputdoex7.Location = new System.Drawing.Point(860, 150);
            this.outputdoex7.Name = "outputdoex7";
            this.outputdoex7.Size = new System.Drawing.Size(86, 40);
            this.outputdoex7.TabIndex = 20;
            this.outputdoex7.Text = "DO 7";
            this.outputdoex7.UseVisualStyleBackColor = true;
            this.outputdoex7.Click += new System.EventHandler(this.outputdoex7_Click);
            // 
            // outputdoex14
            // 
            this.outputdoex14.Location = new System.Drawing.Point(728, 196);
            this.outputdoex14.Name = "outputdoex14";
            this.outputdoex14.Size = new System.Drawing.Size(86, 40);
            this.outputdoex14.TabIndex = 21;
            this.outputdoex14.Text = "DO 14";
            this.outputdoex14.UseVisualStyleBackColor = true;
            this.outputdoex14.Click += new System.EventHandler(this.outputdoex14_Click);
            // 
            // outputdoex6
            // 
            this.outputdoex6.Location = new System.Drawing.Point(728, 150);
            this.outputdoex6.Name = "outputdoex6";
            this.outputdoex6.Size = new System.Drawing.Size(86, 40);
            this.outputdoex6.TabIndex = 22;
            this.outputdoex6.Text = "DO 6";
            this.outputdoex6.UseVisualStyleBackColor = true;
            this.outputdoex6.Click += new System.EventHandler(this.outputdoex6_Click);
            // 
            // outputdoex13
            // 
            this.outputdoex13.Location = new System.Drawing.Point(596, 196);
            this.outputdoex13.Name = "outputdoex13";
            this.outputdoex13.Size = new System.Drawing.Size(86, 40);
            this.outputdoex13.TabIndex = 23;
            this.outputdoex13.Text = "DO 13";
            this.outputdoex13.UseVisualStyleBackColor = true;
            this.outputdoex13.Click += new System.EventHandler(this.outputdoex13_Click);
            // 
            // outputdoex5
            // 
            this.outputdoex5.Location = new System.Drawing.Point(596, 150);
            this.outputdoex5.Name = "outputdoex5";
            this.outputdoex5.Size = new System.Drawing.Size(86, 40);
            this.outputdoex5.TabIndex = 24;
            this.outputdoex5.Text = "DO 5";
            this.outputdoex5.UseVisualStyleBackColor = true;
            this.outputdoex5.Click += new System.EventHandler(this.outputdoex5_Click);
            // 
            // outputdoex12
            // 
            this.outputdoex12.Location = new System.Drawing.Point(494, 196);
            this.outputdoex12.Name = "outputdoex12";
            this.outputdoex12.Size = new System.Drawing.Size(86, 40);
            this.outputdoex12.TabIndex = 25;
            this.outputdoex12.Text = "DO 12";
            this.outputdoex12.UseVisualStyleBackColor = true;
            this.outputdoex12.Click += new System.EventHandler(this.outputdoex12_Click);
            // 
            // outputdoex4
            // 
            this.outputdoex4.Location = new System.Drawing.Point(494, 150);
            this.outputdoex4.Name = "outputdoex4";
            this.outputdoex4.Size = new System.Drawing.Size(86, 40);
            this.outputdoex4.TabIndex = 26;
            this.outputdoex4.Text = "DO 4";
            this.outputdoex4.UseVisualStyleBackColor = true;
            this.outputdoex4.Click += new System.EventHandler(this.outputdoex4_Click);
            // 
            // outputdoex11
            // 
            this.outputdoex11.Location = new System.Drawing.Point(381, 196);
            this.outputdoex11.Name = "outputdoex11";
            this.outputdoex11.Size = new System.Drawing.Size(86, 40);
            this.outputdoex11.TabIndex = 27;
            this.outputdoex11.Text = "DO 11";
            this.outputdoex11.UseVisualStyleBackColor = true;
            this.outputdoex11.Click += new System.EventHandler(this.outputdoex11_Click);
            // 
            // outputdoex3
            // 
            this.outputdoex3.Location = new System.Drawing.Point(381, 150);
            this.outputdoex3.Name = "outputdoex3";
            this.outputdoex3.Size = new System.Drawing.Size(86, 40);
            this.outputdoex3.TabIndex = 28;
            this.outputdoex3.Text = "DO 3";
            this.outputdoex3.UseVisualStyleBackColor = true;
            this.outputdoex3.Click += new System.EventHandler(this.outputdoex3_Click);
            // 
            // outputdoex10
            // 
            this.outputdoex10.Location = new System.Drawing.Point(268, 196);
            this.outputdoex10.Name = "outputdoex10";
            this.outputdoex10.Size = new System.Drawing.Size(86, 40);
            this.outputdoex10.TabIndex = 29;
            this.outputdoex10.Text = "DO 10";
            this.outputdoex10.UseVisualStyleBackColor = true;
            this.outputdoex10.Click += new System.EventHandler(this.outputdoex10_Click);
            // 
            // outputdoex2
            // 
            this.outputdoex2.Location = new System.Drawing.Point(268, 150);
            this.outputdoex2.Name = "outputdoex2";
            this.outputdoex2.Size = new System.Drawing.Size(86, 40);
            this.outputdoex2.TabIndex = 30;
            this.outputdoex2.Text = "DO 2";
            this.outputdoex2.UseVisualStyleBackColor = true;
            this.outputdoex2.Click += new System.EventHandler(this.outputdoex2_Click);
            // 
            // outputdoex9
            // 
            this.outputdoex9.Location = new System.Drawing.Point(164, 196);
            this.outputdoex9.Name = "outputdoex9";
            this.outputdoex9.Size = new System.Drawing.Size(86, 40);
            this.outputdoex9.TabIndex = 31;
            this.outputdoex9.Text = "DO 9";
            this.outputdoex9.UseVisualStyleBackColor = true;
            this.outputdoex9.Click += new System.EventHandler(this.outputdoex9_Click);
            // 
            // outputdoex1
            // 
            this.outputdoex1.Location = new System.Drawing.Point(164, 150);
            this.outputdoex1.Name = "outputdoex1";
            this.outputdoex1.Size = new System.Drawing.Size(86, 40);
            this.outputdoex1.TabIndex = 32;
            this.outputdoex1.Text = "DO 1";
            this.outputdoex1.UseVisualStyleBackColor = true;
            this.outputdoex1.Click += new System.EventHandler(this.outputdoex1_Click);
            // 
            // outputdoex8
            // 
            this.outputdoex8.Location = new System.Drawing.Point(62, 196);
            this.outputdoex8.Name = "outputdoex8";
            this.outputdoex8.Size = new System.Drawing.Size(86, 40);
            this.outputdoex8.TabIndex = 33;
            this.outputdoex8.Text = "DO 8";
            this.outputdoex8.UseVisualStyleBackColor = true;
            this.outputdoex8.Click += new System.EventHandler(this.outputdoex8_Click);
            // 
            // outputdoex0
            // 
            this.outputdoex0.Location = new System.Drawing.Point(62, 150);
            this.outputdoex0.Name = "outputdoex0";
            this.outputdoex0.Size = new System.Drawing.Size(86, 40);
            this.outputdoex0.TabIndex = 34;
            this.outputdoex0.Text = "DO 0";
            this.outputdoex0.UseVisualStyleBackColor = true;
            this.outputdoex0.Click += new System.EventHandler(this.outputdoex0_Click);
            // 
            // SCANIex4
            // 
            this.SCANIex4.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex4.Location = new System.Drawing.Point(494, 80);
            this.SCANIex4.Name = "SCANIex4";
            this.SCANIex4.Size = new System.Drawing.Size(86, 22);
            this.SCANIex4.TabIndex = 3;
            this.SCANIex4.Text = "  DI4";
            // 
            // SCANIex0
            // 
            this.SCANIex0.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex0.Location = new System.Drawing.Point(62, 80);
            this.SCANIex0.Name = "SCANIex0";
            this.SCANIex0.Size = new System.Drawing.Size(86, 22);
            this.SCANIex0.TabIndex = 4;
            this.SCANIex0.Text = "  DI0";
            // 
            // SCANIex15
            // 
            this.SCANIex15.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex15.Location = new System.Drawing.Point(860, 117);
            this.SCANIex15.Name = "SCANIex15";
            this.SCANIex15.Size = new System.Drawing.Size(86, 22);
            this.SCANIex15.TabIndex = 5;
            this.SCANIex15.Text = "  DI15";
            // 
            // SCANIex1
            // 
            this.SCANIex1.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex1.Location = new System.Drawing.Point(164, 80);
            this.SCANIex1.Name = "SCANIex1";
            this.SCANIex1.Size = new System.Drawing.Size(86, 22);
            this.SCANIex1.TabIndex = 6;
            this.SCANIex1.Text = "  DI1";
            // 
            // SCANIex7
            // 
            this.SCANIex7.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex7.Location = new System.Drawing.Point(860, 80);
            this.SCANIex7.Name = "SCANIex7";
            this.SCANIex7.Size = new System.Drawing.Size(86, 22);
            this.SCANIex7.TabIndex = 7;
            this.SCANIex7.Text = "  DI7";
            // 
            // SCANIex8
            // 
            this.SCANIex8.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex8.Location = new System.Drawing.Point(62, 116);
            this.SCANIex8.Name = "SCANIex8";
            this.SCANIex8.Size = new System.Drawing.Size(86, 22);
            this.SCANIex8.TabIndex = 8;
            this.SCANIex8.Text = "  DI8";
            // 
            // SCANIex14
            // 
            this.SCANIex14.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex14.Location = new System.Drawing.Point(728, 117);
            this.SCANIex14.Name = "SCANIex14";
            this.SCANIex14.Size = new System.Drawing.Size(86, 22);
            this.SCANIex14.TabIndex = 9;
            this.SCANIex14.Text = "  DI14";
            // 
            // SCANIex2
            // 
            this.SCANIex2.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex2.Location = new System.Drawing.Point(270, 80);
            this.SCANIex2.Name = "SCANIex2";
            this.SCANIex2.Size = new System.Drawing.Size(86, 22);
            this.SCANIex2.TabIndex = 10;
            this.SCANIex2.Text = "  DI2";
            // 
            // SCANIex6
            // 
            this.SCANIex6.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex6.Location = new System.Drawing.Point(728, 80);
            this.SCANIex6.Name = "SCANIex6";
            this.SCANIex6.Size = new System.Drawing.Size(86, 22);
            this.SCANIex6.TabIndex = 11;
            this.SCANIex6.Text = "  DI6";
            // 
            // SCANIex9
            // 
            this.SCANIex9.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex9.Location = new System.Drawing.Point(164, 117);
            this.SCANIex9.Name = "SCANIex9";
            this.SCANIex9.Size = new System.Drawing.Size(86, 22);
            this.SCANIex9.TabIndex = 12;
            this.SCANIex9.Text = "  DI9";
            // 
            // SCANIex13
            // 
            this.SCANIex13.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex13.Location = new System.Drawing.Point(596, 117);
            this.SCANIex13.Name = "SCANIex13";
            this.SCANIex13.Size = new System.Drawing.Size(86, 22);
            this.SCANIex13.TabIndex = 13;
            this.SCANIex13.Text = "  DI13";
            // 
            // SCANIex3
            // 
            this.SCANIex3.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex3.Location = new System.Drawing.Point(380, 80);
            this.SCANIex3.Name = "SCANIex3";
            this.SCANIex3.Size = new System.Drawing.Size(86, 22);
            this.SCANIex3.TabIndex = 14;
            this.SCANIex3.Text = "  DI3";
            // 
            // SCANIex5
            // 
            this.SCANIex5.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex5.Location = new System.Drawing.Point(596, 80);
            this.SCANIex5.Name = "SCANIex5";
            this.SCANIex5.Size = new System.Drawing.Size(86, 22);
            this.SCANIex5.TabIndex = 15;
            this.SCANIex5.Text = "  DI5";
            // 
            // SCANIex10
            // 
            this.SCANIex10.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex10.Location = new System.Drawing.Point(270, 116);
            this.SCANIex10.Name = "SCANIex10";
            this.SCANIex10.Size = new System.Drawing.Size(86, 22);
            this.SCANIex10.TabIndex = 16;
            this.SCANIex10.Text = "  DI10";
            // 
            // SCANIex12
            // 
            this.SCANIex12.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex12.Location = new System.Drawing.Point(494, 117);
            this.SCANIex12.Name = "SCANIex12";
            this.SCANIex12.Size = new System.Drawing.Size(86, 22);
            this.SCANIex12.TabIndex = 17;
            this.SCANIex12.Text = "  DI12";
            // 
            // SCANIex11
            // 
            this.SCANIex11.BackColor = System.Drawing.Color.LightGray;
            this.SCANIex11.Location = new System.Drawing.Point(380, 117);
            this.SCANIex11.Name = "SCANIex11";
            this.SCANIex11.Size = new System.Drawing.Size(86, 22);
            this.SCANIex11.TabIndex = 18;
            this.SCANIex11.Text = "  DI11";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(244, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 33);
            this.button2.TabIndex = 2;
            this.button2.Text = "初始化模块";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "模块站号";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15"});
            this.comboBox1.Location = new System.Drawing.Point(93, 24);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 26);
            this.comboBox1.TabIndex = 0;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1226, 624);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.button1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.closed);
            this.Load += new System.EventHandler(this.load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timerSANIO;
        private System.Windows.Forms.Label SANI5;
        private System.Windows.Forms.Label SANI1;
        private System.Windows.Forms.Label SANI2;
        private System.Windows.Forms.Label SANI8;
        private System.Windows.Forms.Label SANI9;
        private System.Windows.Forms.Label SANI3;
        private System.Windows.Forms.Label SANI7;
        private System.Windows.Forms.Label SANI10;
        private System.Windows.Forms.Label SANI4;
        private System.Windows.Forms.Label SANI6;
        private System.Windows.Forms.Label SANI11;
        private System.Windows.Forms.Label SANI12;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button output15;
        private System.Windows.Forms.Button output7;
        private System.Windows.Forms.Button output14;
        private System.Windows.Forms.Button output6;
        private System.Windows.Forms.Button output13;
        private System.Windows.Forms.Button output5;
        private System.Windows.Forms.Button output12;
        private System.Windows.Forms.Button output4;
        private System.Windows.Forms.Button output11;
        private System.Windows.Forms.Button output3;
        private System.Windows.Forms.Button output10;
        private System.Windows.Forms.Button output2;
        private System.Windows.Forms.Button output9;
        private System.Windows.Forms.Button output1;
        private System.Windows.Forms.Button output8;
        private System.Windows.Forms.Button output0;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button Alarm0;
        private System.Windows.Forms.Button Alarm10;
        private System.Windows.Forms.Button Alarm7;
        private System.Windows.Forms.Button Alarm4;
        private System.Windows.Forms.Button Alarm9;
        private System.Windows.Forms.Button Alarm6;
        private System.Windows.Forms.Button Alarm3;
        private System.Windows.Forms.Button Alarm1;
        private System.Windows.Forms.Button Alarm11;
        private System.Windows.Forms.Button Alarm8;
        private System.Windows.Forms.Button Alarm5;
        private System.Windows.Forms.Button Alarm2;
        private System.Windows.Forms.Button Alarm16;
        private System.Windows.Forms.Button Alarm15;
        private System.Windows.Forms.Button Alarm13;
        private System.Windows.Forms.Button Alarm17;
        private System.Windows.Forms.Button Alarm14;
        private System.Windows.Forms.Button Alarm12;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button outputdoex15;
        private System.Windows.Forms.Button outputdoex7;
        private System.Windows.Forms.Button outputdoex14;
        private System.Windows.Forms.Button outputdoex6;
        private System.Windows.Forms.Button outputdoex13;
        private System.Windows.Forms.Button outputdoex5;
        private System.Windows.Forms.Button outputdoex12;
        private System.Windows.Forms.Button outputdoex4;
        private System.Windows.Forms.Button outputdoex11;
        private System.Windows.Forms.Button outputdoex3;
        private System.Windows.Forms.Button outputdoex10;
        private System.Windows.Forms.Button outputdoex2;
        private System.Windows.Forms.Button outputdoex9;
        private System.Windows.Forms.Button outputdoex1;
        private System.Windows.Forms.Button outputdoex8;
        private System.Windows.Forms.Button outputdoex0;
        private System.Windows.Forms.Label SCANIex4;
        private System.Windows.Forms.Label SCANIex0;
        private System.Windows.Forms.Label SCANIex15;
        private System.Windows.Forms.Label SCANIex1;
        private System.Windows.Forms.Label SCANIex7;
        private System.Windows.Forms.Label SCANIex8;
        private System.Windows.Forms.Label SCANIex14;
        private System.Windows.Forms.Label SCANIex2;
        private System.Windows.Forms.Label SCANIex6;
        private System.Windows.Forms.Label SCANIex9;
        private System.Windows.Forms.Label SCANIex13;
        private System.Windows.Forms.Label SCANIex3;
        private System.Windows.Forms.Label SCANIex5;
        private System.Windows.Forms.Label SCANIex10;
        private System.Windows.Forms.Label SCANIex12;
        private System.Windows.Forms.Label SCANIex11;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
    }
}